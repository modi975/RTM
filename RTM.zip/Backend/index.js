const express = require('express');
const bodyParser = require('body-parser');
const app = express();
var cors = require('cors');
const port = 3000;
const db = require('./connection');
app.use(bodyParser.json());
app.use(
    bodyParser.urlencoded({
        extended: true
    })
);
app.use(cors())
app.get('/retailers', db.getRetailers)
app.get('/route', db.getRoute)
app.get('/distributorcode', db.getDistributorCode)
app.get('/category', db.getCategory) 
app.get('/getmonthvaluebyroute',db.getMonthValueByRoute)  
app.get('/getmonthvaluebyretailer',db.getMonthValueByRetailer)
app.get('/julybyroute',db.getJulybyRoute);
app.get('/getallmonthtotal',db.getAllMonthTotal)
app.get('/databyretailers',db.dataFilteredByRetailers)
app.get('/databyroutes',db.dataFilteredByRoutes)
app.post('/alldata',db.getAllChartsData)
// app.get('/users', (req,res) => {
//     db.query('select * from final_data', (error, results) => {
//         if (error) {
//           throw error
//         }
//         console.log(results)
//         res.status(200).json(results.rows)
//       })
// })
app.listen(port , () => {
    console.log('App running on port',port);
})