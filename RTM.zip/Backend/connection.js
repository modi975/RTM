const Pool = require('pg').Pool;
const pg = require('pg')
//var conString = "pg://admin:Amitabh123@89a017f3-c192-47d8-abe2-985df9d0f25c.a618efcd6c3341158fb843970f0d7edd.databases.appdomain.cloud:30901/ibmclouddb";
var client = new pg.Client({
    user: 'admin',
    host: '89a017f3-c192-47d8-abe2-985df9d0f25c.a618efcd6c3341158fb843970f0d7edd.databases.appdomain.cloud',
    database: 'ibmclouddb',
    password: 'Amitabh123',
    port: '30901',
    ssl: true
});
client.connect();

// const pool = new Pool({
//     user: 'admin',
//     host: '89a017f3-c192-47d8-abe2-985df9d0f25c.a618efcd6c3341158fb843970f0d7edd.databases.appdomain.cloud',
//     database: 'ibmclouddb',
//     password: 'Amitabh123',
//     port: '30901',
//     ssl: true
// })
const getRetailers = (request, response) => {
    client.query(`select distinct "Retailer_Name" from final_data`, (error, results) => {
        if (error) {
            throw error
        }
        //console.log(results)
        //   let temparray = [];    
        //   for (i = 0; i < results.rows.length; i++){
        //     temparray.push(results.rows[i].value);
        //   }
        //   console.log(temparray);
        //   responseData ={};
        response.status(200).json(results.rows)
    })
}
const getCategory = (request, response) => {
    client.query(`select distinct "Category" from final_data`, (error, results) => {
        if (error) {
            throw error
        }
        console.log(results)
        response.status(200).json(results.rows)
    })
}
const getRoute = (request, response) => {
    client.query(`select distinct "Route" from final_data`, (error, results) => {
        if (error) {
            throw error
        }
        console.log(results)
        response.status(200).json(results.rows)
    })
}
const getDistributorCode = (request, response) => {
    client.query(`select distinct "Distributor_Code" from final_data`, (error, results) => {
        if (error) {
            throw error
        }
        console.log(results)
        response.status(200).json(results.rows)
    })
}
const getMonthValueByRoute = (req, res) => {
    let mayData = [];
    let juneData = [];
    let julyData = [];
    client.query(`select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data group by "Route"`, (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayData.push(temp[0]);
            juneData.push(temp[1]);
            julyData.push(temp[2])
        });
        res.status(200).send({ mayData, juneData, julyData })
    })
}
const getMonthValueByRetailer = (req, res) => {
    let mayData = [];
    let juneData = [];
    let julyData = [];
    client.query(`select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data group by "Retailer_Name"`, (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayData.push(temp[0]);
            juneData.push(temp[1]);
            julyData.push(temp[2])
        });
        res.status(200).send({ mayData, juneData, julyData })
    })
}
const getJulybyRoute = (req, res) => {
    let julySum = [];
    client.query(`select sum("Qty_july_retailer") from final_data group by "Route"`, (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element);
            julySum.push(temp[0])
        })
        res.status(200).send({ julySum })
    })
}
const getAllMonthTotal = (req, res) => {
    let juneSum = 0;
    let maySum = 0;
    let julySum = 0;
    client.query(`select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as 
    JulySum from final_data`, (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            maySum = maySum + parseInt(temp[0]);
            juneSum = juneSum + parseInt(temp[1]);
            julySum = julySum + parseInt(temp[2]);
        });
        res.status(200).send({ maySum, juneSum, julySum })
    })
}
const dataFilteredByRetailers = (req, res) => {
    let filterString
    let filter = (req.query.data)
    for (let index = 0; index < filter.length; index++) {
        if (index == 0) {
            filterString = `'` + filter[0] + `'`
        }
        else {
            filterString = filterString + `,'` + filter[index] + `'`
        }
    }
    console.log(filterString)
    let mayDataRoute = [];
    let juneDataRoute = [];
    let julyDataRoute = [];
    let mayDataRetailer = [];
    let juneDataRetailer = [];
    let julyDataRetailer = [];
    client.query(
        `select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as 
    JulySum from final_data where "Retailer_Name" in (${filterString}) group by "Route"`, 
    (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRoute.push(temp[0]);
            juneDataRoute.push(temp[1]);
            julyDataRoute.push(temp[2])
        });
    });
    client.query(
        `select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as 
    JulySum from final_data where "Retailer_Name" in (${filterString}) group by "Retailer_Name"`, 
    (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRetailer.push(temp[0]);
            juneDataRetailer.push(temp[1]);
            julyDataRetailer.push(temp[2])
        });
    })
    let responseData = {
        route : {
            mayDataRoute,
            juneDataRoute,
            julyDataRoute
        },
        retailer:{
            mayDataRetailer,
            juneDataRetailer,
            julyDataRetailer
        }
    }
    res.status(200).send(responseData)
}
const dataFilteredByRoutes = (req,res) => {
    let filterString;
    console.log(req.query.data)
    let filterData = (req.query.data);
    for (let index = 0; index < filterData.length; index++) {
        if (index == 0) {
            filterString = `'` + filterData[0] + `'`
        }
        else {
            filterString = filterString + `,'` + filterData[index] + `'`
        }
    }
    let mayDataRoute = [];
    let juneDataRoute = [];
    let julyDataRoute = [];
    let mayDataRetailer = [];
    let juneDataRetailer = [];
    let julyDataRetailer = [];
    client.query(
        `select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as 
    JulySum from final_data where "Route" in (${filterString}) group by "Route"`, 
    (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRoute.push(temp[0]);
            juneDataRoute.push(temp[1]);
            julyDataRoute.push(temp[2])
        });
    });
    client.query(
        `select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as 
    JulySum from final_data where "Route" in (${filterString}) group by "Retailer_Name"`, 
    (error, results) => {
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRetailer.push(temp[0]);
            juneDataRetailer.push(temp[1]);
            julyDataRetailer.push(temp[2])
        });
    })
    let responseData = {
        route : {
            mayDataRoute,
            juneDataRoute,
            julyDataRoute
        },
        retailer:{
            mayDataRetailer,
            juneDataRetailer,
            julyDataRetailer
        }
    }
    res.status(200).send(responseData)
}
    
    let categoryString;
    let distributorString;
    let routeString;
    let retailerString;
    
const getAllChartsData = (req,res) => {
    let retailerPresent =false;
    let routePresent = false;
    let categoryPresent = false;
    let distributorPresent = false;
    let sumDataQuery = `select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as JulySum from final_data`;
    let monthvaluebyRouteQuery = `select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data`
    let monthvaluebyRetailerQuery = `select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data`
    let julyvalueQuery = `select sum("Qty_july_retailer") from final_data`;
    let divisionQuery = `select distinct "Division" from final_data`;
    let monthSumQuery = `select sum("Qty_may_retailer") as MayTotalSum,sum("Qty_june_retailer") as JuneTotalSum,sum("Qty_july_retailer") as JulTotalySum from final_data`
    let mayDataRoute = [];
    let juneDataRoute = [];
    let julyDataRoute = [];
    let mayDataRetailer = [];
    let juneDataRetailer = [];
    let julyDataRetailer = [];
    let julySum
    let juneSum
    let maySum;
    let julyTotalSum;
    let mayTotalSum;
    let juneTotalSum;
    let allmonthSum;
    let julyData = [];
    let division = [];
    let calcDone = false;
    console.log("query response",req.query.data)
    console.log("body",req.body)
    let categoryName = req.body[2];
    console.log(categoryName.length)
    let distributorCode  = req.body[1];
    console.log(distributorCode.length)
    let route = req.body[3];
    console.log(route.length)
    let retailerName = req.body[0];
    console.log(retailerName.length)
    if(categoryName.length != 0){
        for (let index = 0; index < categoryName.length; index++) {
            if (index == 0) {
                categoryString = `'` + categoryName[0] + `'`
            }
            else {
                categoryString = categoryString + `,'` + categoryName[index] + `'`
            }
        }
        categoryPresent = true;
        let sumind = sumDataQuery.indexOf('where');
        let routemonthind = monthvaluebyRouteQuery.indexOf('where');
        let retailermonthind = monthvaluebyRetailerQuery.indexOf('where');
        let julysumind = julyvalueQuery.indexOf('where');
        let divind = divisionQuery.indexOf('where');
        let totalsumind = monthSumQuery.indexOf('where');
        sumDataQuery = sumind > -1 ? sumDataQuery + ` and "Category" in (${categoryString})` : sumDataQuery + ` where "Category" in (${categoryString})`
            console.log('category query',sumDataQuery)
        monthvaluebyRouteQuery = routemonthind > -1 ? monthvaluebyRouteQuery + ` and "Category" in (${categoryString})` : monthvaluebyRouteQuery + ` where "Category" in (${categoryString})`
            console.log('category query',monthvaluebyRouteQuery)
        monthvaluebyRetailerQuery = retailermonthind > -1 ? monthvaluebyRetailerQuery + ` and "Category" in (${categoryString})` : monthvaluebyRetailerQuery + ` where "Category" in (${categoryString})`
            console.log('category query',monthvaluebyRetailerQuery)
        julyvalueQuery = julysumind > -1 ? julyvalueQuery + ` and "Category" in (${categoryString})` : julyvalueQuery + ` where "Category" in (${categoryString})`
            console.log('category query',julyvalueQuery)
        divisionQuery = divind > -1 ? divisionQuery + ` and "Category" in (${categoryString})` : divisionQuery + ` where "Category" in (${categoryString})`
        monthSumQuery = totalsumind > -1 ? monthSumQuery + ` and "Category" in (${categoryString})` : monthSumQuery + ` where "Category" in (${categoryString})`
    }
    if(distributorCode.length != 0){
        distributorPresent =true;
        for (let index = 0; index < distributorCode.length; index++) {
            if (index == 0) {
                distributorString = `'` + distributorCode[0] + `'`
            }
            else {
                distributorString = distributorString + `,'` + distributorCode[index] + `'`
            }
        }
        let sumind = sumDataQuery.indexOf('where');
        let routemonthind = monthvaluebyRouteQuery.indexOf('where');
        let retailermonthind = monthvaluebyRetailerQuery.indexOf('where');
        let julysumind = julyvalueQuery.indexOf('where');
        let divind = divisionQuery.indexOf('where');
        let totalsumind = monthSumQuery.indexOf('where');
        sumDataQuery = sumind > -1 ? sumDataQuery + ` and "Distributor_Code" in (${distributorString})` : sumDataQuery + ` where "Distributor_Code" in (${distributorString})`
            console.log('distributorString query',sumDataQuery)
        monthvaluebyRouteQuery = routemonthind > -1 ? monthvaluebyRouteQuery + ` and "Distributor_Code" in (${distributorString})` : monthvaluebyRouteQuery + ` where "Distributor_Code" in (${distributorString})`
            console.log('distributorString query',monthvaluebyRouteQuery)
        monthvaluebyRetailerQuery = retailermonthind > -1 ? monthvaluebyRetailerQuery + ` and "Distributor_Code" in (${distributorString})` : monthvaluebyRetailerQuery + ` where "Distributor_Code" in (${distributorString})`
            console.log('distributorString query',monthvaluebyRetailerQuery)
        julyvalueQuery = julysumind > -1 ? julyvalueQuery + ` and "Distributor_Code" in (${distributorString})` : julyvalueQuery + ` where "Distributor_Code" in (${distributorString})`
            console.log('distributorString query',julyvalueQuery)
        divisionQuery = divind > -1 ? divisionQuery + ` and "Distributor_Code" in (${distributorString})` : divisionQuery + ` where "Distributor_Code" in (${distributorString})`
        monthSumQuery = totalsumind > -1 ? monthSumQuery + ` and "Distributor_Code" in (${distributorString})` : monthSumQuery + ` where "Distributor_Code" in (${distributorString})`
    }
    if(route.length != 0){
        routePresent = true;
        for (let index = 0; index < route.length; index++) {
            if (index == 0) {
                routeString = `'` + route[0] + `'`
            }
            else {
                routeString = routeString + `,'` + route[index] + `'`
            }
        }
        console.log(routeString);
        let sumind = sumDataQuery.indexOf('where');
        let routemonthind = monthvaluebyRouteQuery.indexOf('where');
        let retailermonthind = monthvaluebyRetailerQuery.indexOf('where');
        let julysumind = julyvalueQuery.indexOf('where');
        let divind = divisionQuery.indexOf('where');
        let totalsumind = monthSumQuery.indexOf('where');
        sumDataQuery = sumind > -1 ? sumDataQuery + ` and "Route" in (${routeString})` : sumDataQuery + ` where "Route" in (${routeString})`
            console.log('routeString query',sumDataQuery)
        monthvaluebyRouteQuery = routemonthind > -1 ? monthvaluebyRouteQuery + ` and "Route" in (${routeString})` : monthvaluebyRouteQuery + ` where "Route" in (${routeString})`
            console.log('routeString query',monthvaluebyRouteQuery)
        monthvaluebyRetailerQuery = retailermonthind > -1 ? monthvaluebyRetailerQuery + ` and "Route" in (${routeString})` : monthvaluebyRetailerQuery + ` where "Route" in (${routeString})`
            console.log('routeString query',monthvaluebyRetailerQuery)
        julyvalueQuery = julysumind > -1 ? julyvalueQuery + ` and "Route" in (${routeString})` : julyvalueQuery + ` where "Route" in (${routeString})`
            console.log('distributorString query',julyvalueQuery)
        divisionQuery = divind > -1 ? divisionQuery + ` and "Route" in (${routeString})` : divisionQuery + ` where "Route" in (${routeString})`
        monthSumQuery = totalsumind > -1 ? monthSumQuery + ` and "Route" in (${routeString})` : monthSumQuery + ` where "Route" in (${routeString})`
    }
    if(retailerName.length != 0){
        retailerPresent = true;
        for (let index = 0; index < retailerName.length; index++) {
            if (index == 0) {
                retailerString = `'` + retailerName[0] + `'`
            }
            else {
                retailerString = retailerString + `,'` + retailerName[index] + `'`
            }
        }
        console.log(retailerString);
        let sumind = sumDataQuery.indexOf('where');
        let routemonthind = monthvaluebyRouteQuery.indexOf('where');
        let retailermonthind = monthvaluebyRetailerQuery.indexOf('where');
        let julysumind = julyvalueQuery.indexOf('where');
        let divind = divisionQuery.indexOf('where');
        let totalsumind = monthSumQuery.indexOf('where');
        sumDataQuery = sumind > -1 ? sumDataQuery + ` and "Retailer_Name" in (${retailerString})` : sumDataQuery + ` where "Retailer_Name" in (${retailerString})`
            console.log('retailerString query',sumDataQuery)
        monthvaluebyRouteQuery = routemonthind > -1 ? monthvaluebyRouteQuery + ` and "Retailer_Name" in (${retailerString})` : monthvaluebyRouteQuery + ` where "Retailer_Name" in (${retailerString})`
            console.log('retailerString query',monthvaluebyRouteQuery)
        monthvaluebyRetailerQuery = retailermonthind > -1 ? monthvaluebyRetailerQuery + ` and "Retailer_Name" in (${retailerString})` : monthvaluebyRetailerQuery + ` where "Retailer_Name" in (${retailerString})`
            console.log('retailerString query',monthvaluebyRetailerQuery)
        julyvalueQuery = julysumind > -1 ? julyvalueQuery + ` and "Retailer_Name" in (${retailerString})` : julyvalueQuery + ` where "Retailer_Name" in (${retailerString})`
            console.log('retailerString query',julyvalueQuery)
        divisionQuery = divind > -1 ? divisionQuery + ` and "Retailer_Name" in (${retailerString})` : divisionQuery + ` where "Retailer_Name" in (${retailerString})`
        monthSumQuery = totalsumind > -1 ? monthSumQuery + ` and "Retailer_Name" in (${retailerString})` : monthSumQuery + ` where "Retailer_Name" in (${retailerString})`
    }
    if(retailerPresent == false && routePresent == false && categoryPresent == false && distributorPresent == false){
        sumDataQuery = 'select sum("Qty_may_retailer") as MaySum,sum("Qty_june_retailer") as JuneSum,sum("Qty_july_retailer") as JulySum from final_data';
        monthvaluebyRouteQuery = 'select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data group by "Route"'
        monthvaluebyRetailerQuery = 'select sum("Qty_may_retailer") as May,sum("Qty_june_retailer") as June,sum("Qty_july_retailer") as July from final_data group by "Retailer_Name"'
        julyvalueQuery = 'select sum("Qty_july_retailer") from final_data group by "Route"';
        divisionQuery = `select distinct "Division" from final_data`;
        console.log(sumDataQuery,monthvaluebyRouteQuery,monthvaluebyRetailerQuery,julyvalueQuery)
    }
    else{
        monthvaluebyRouteQuery = monthvaluebyRouteQuery + `group by "Route"`;
        monthvaluebyRetailerQuery = monthvaluebyRetailerQuery + `group by "Retailer_Name"`;
        julyvalueQuery = julyvalueQuery + `group by "Route"`;
    }
    
    client.query(sumDataQuery, (error,results) => {
        console.log('--------------------------------------------');
        //console.log(results.rows)
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            console.log('+++++++++++++++++++++++++++++++++++++++++++++')
            
            maySum =  parseInt(temp[0]);
            juneSum = parseInt(temp[1]);
            julySum = parseInt(temp[2]);
        });
    });
    client.query(monthSumQuery, (error,results) => {
        if(error){
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element);
            let may = parseInt(temp[0]);
            let june = parseInt(temp[1]);
            let july = parseInt(temp[2]);
            allmonthSum = may + june + july;
            mayTotalSum = (may/allmonthSum)*100;
            juneTotalSum = (june/allmonthSum)*100;
            julyTotalSum = (july/allmonthSum)*100;
            
        })
    })
    client.query(monthvaluebyRouteQuery, (error,results) => {
        console.log('--------------------------------------------');
        //console.log(results.rows)
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRoute.push(parseInt(temp[0]));
            juneDataRoute.push(parseInt(temp[1]));
            julyDataRoute.push(parseInt(temp[2]))
        });
    });
    client.query(monthvaluebyRetailerQuery, (error,results) => {
        console.log('--------------------------------------------');
        //console.log(results.rows)
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element)
            mayDataRetailer.push(parseInt(temp[0]));
            juneDataRetailer.push(parseInt(temp[1]));
            julyDataRetailer.push(parseInt(temp[2]));
        });
    });
    client.query(divisionQuery, (error,results) => {
        if(error){
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element);
            division.push(temp[0]);
        })
    })
    client.query(julyvalueQuery, (error,results) => {
        console.log('--------------------------------------------');
        //console.log(results.rows)
        if (error) {
            throw error
        }
        results.rows.forEach(element => {
            let temp = Object.values(element);
            julyData.push(temp[0])
        })
        let responseData = {
            retailer : {
                mayDataRetailer,
                juneDataRetailer,
                julyDataRetailer
            },
            route:{
                mayDataRoute,
                juneDataRoute,
                julyDataRoute
            },
            monthSum:{
                maySum,
                juneSum,
                julySum
            },
            julyData:{
                julyData
            },
            div:{
                division
            },
            allMonthData:{
                mayTotalSum,
                juneTotalSum,
                julyTotalSum,
            }
        }
        console.log(responseData);
        sumDataQuery = '';
        monthvaluebyRetailerQuery = '';
        monthvaluebyRouteQuery = '';
        julyvalueQuery = '';
        divisionQuery = '';
        monthSumQuery = '';
        res.status(200).send(responseData);
    });
        
}
module.exports = {
    getRetailers,
    getDistributorCode,
    getRoute,
    getCategory,
    getJulybyRoute,
    getMonthValueByRoute,
    getMonthValueByRetailer,
    getAllMonthTotal,
    dataFilteredByRetailers,
    dataFilteredByRoutes,
    getAllChartsData
    // client
}