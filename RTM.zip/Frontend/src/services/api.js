import Vue from 'vue';
import axios from 'axios';

const client = axios.create({
    baseURL : 'http://localhost:3000',
    json: true
});

export default{
    async executte (method, resource , data){
        console.log(data)
        return new Promise((resolve, reject)=>{
            return client({
                method,
                url: resource,
                data
            }).then(req => {
                resolve( req.data )
                console.log(req.data)
            })
        })
        },
    getRetailers(){
        return this.executte('get','/retailers')
    },
    getRoute(){
        return this.executte('get','/route')
    },
    getDistributorCode(){
        return this.executte('get','/distributorcode')
    },
    getCategory(){
        return this.executte('get','/category')
    },
    getMonthValueByRetailer(){
        return this.executte('get','/getmonthvaluebyretailer')
    },
    getJulybyRoute(){
        return this.executte('get','/julybyroute')
    },
    getMonthValueByRoute(){
        return this.executte('get','/getmonthvaluebyroute')
    },
    getMonthTotal(){
        return this.executte('get','/getallmonthtotal');
    },
    getDataBasedonRetailer(retailerFilter){
        return this.executte('get','/databyretailers',retailerFilter)
    },
    getDataBasedonRoute(routeFilter){
        console.log(routeFilter)
        return this.executte('get','/databyroutes',routeFilter)
    },
    fetchAllData(filterArray){
        return this.executte('post','/alldata',filterArray)
    }
}