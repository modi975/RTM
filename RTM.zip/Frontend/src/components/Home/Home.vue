<template>
  <!-- <div>{{Retailers}}</div> -->
  <div class="container-fluid">
    <div class="row headerrow">
      <div class="col-3">
        <div class="text-center headerdiv">Retailer Name</div>
        <div class="dropdown">
          <button
            class="btn btn-sm btn-secondary dropdown-toggle dropdownbutton"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >{{retailerDropdownValue}}</button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <ul class="customdown">
              <li v-for="(retailer,index)  in Retailers" :key="index">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" v-on:click="fetchAllChartData(retailer,'rn')"/>
                    {{retailer}}
                  </label>
                </div>
              </li>
            </ul>
          </div>
          <!-- <infinite-loading @infinite="infiniteHandler"></infinite-loading> -->
        </div>
      </div>
      <div class="col-3">
        <div class="text-center headerdiv">Category Name</div>
        <div class="dropdown">
          <button
            class="btn btn-sm btn-secondary dropdown-toggle dropdownbutton"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >{{categoryDropdownValue}}</button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <ul class="customdown">
              <li v-for="category in Category" :key="category.Category">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" v-on:click="fetchAllChartData(category.Category,'c')"/>
                    {{category.Category}}
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="text-center headerdiv">Distributor Code</div>
        <div class="dropdown">
          <button
            class="btn btn-sm btn-secondary dropdown-toggle dropdownbutton"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >{{distributorDropdownValue}}</button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <ul class="customdown">
              <li v-for="dc in DistributorCode" :key="dc.Distributor_Code">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" v-on:click="fetchAllChartData(dc.Distributor_Code,'dc')"/>
                    {{dc.Distributor_Code}}
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      <div class="col-3">
        <div class="text-center headerdiv">Route</div>
        <div class="dropdown">
          <button
            class="btn btn-sm btn-secondary dropdown-toggle dropdownbutton"
            type="button"
            id="dropdownMenuButton"
            data-toggle="dropdown"
            aria-haspopup="true"
            aria-expanded="false"
          >{{routeDropdownValue}}</button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <ul class="customdown">
              <li v-for="(route,index) in Routes" :key="index">
                <div class="checkbox">
                  <label>
                    <input type="checkbox" v-on:click="fetchAllChartData(route,'r')"/>
                    {{route}}
                  </label>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="row" style="
    margin-left: 10px;
    margin-right: 10px;">
        <div class="col-5 card" id="chart" style="height:100%;">
            <div v-if="byRouteLoaded == false">
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
            </div>
            <div v-else style="overflow:auto">
            <highcharts :options="options"></highcharts>
            </div>
        </div>
        <div class="col-2">
            <div
            v-if="divisionLoaded == false"
            >
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
            </div>
            <div v-else>
              <highcharts :options="divisionpieOptions"></highcharts>
            </div>
            <div
            v-if="qtyTotalLoaded == false"
            >
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
            </div>
            <div v-else>
              <highcharts :options="totalQtyOptions"></highcharts>
            </div>
        </div>
        <div class="col-5 card">
            <div
            v-if="byReatilerLoaded == false"
            >
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
            </div>
            <div v-else>
            <highcharts :options="retailerOptions"></highcharts>
            </div>
        </div>
    </div>
    <div class="row" style="
    margin-left: 10px;
    margin-right: 10px;">
      <div class="col-5 card" style="height:100%;margin-top:50px">
        <div v-if="monthbyRouteLoaded == false">
          <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
        </div>
        <div v-else>
          <highcharts :options="currentMonthOptions"></highcharts>
        </div>
      </div>
      <div class="col-2" style="margin-top:50px;height:300px">
        <div style="background:yellow;height:33%">
          <div v-if="juneTotalSum == 0">
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
          </div>
          <div v-else>
            <div
              class="text-center"
              style="padding-bottom:14px;padding-top:10px;font-weight:bold"
            >Quantity (For May)</div>
            <div class="text-center" style="font-size:30px">{{mayTotalSum}}</div>
          </div>
        </div>
        <div style="background:#f7f79a;height:33%">
          <div v-if="juneTotalSum == 0">
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
          </div>
          <div v-else>
            <div
              class="text-center"
              style="padding-bottom:14px;padding-top:10px;font-weight:bold"
            >Quantity (For June)</div>
            <div class="text-center" style="font-size:30px">{{juneTotalSum}}</div>
          </div>
        </div>
        <div style="background:#e2e2a7;height:33%">
          <div v-if="julyTotalSum == 0">
            <vue-loaders-ball-beat color="black" scale="1"></vue-loaders-ball-beat>
          </div>
          <div v-else>
            <div
              class="text-center"
              style="padding-bottom:14px;padding-top:10px;font-weight:bold"
            >Quantity (For July)</div>
            <div class="text-center" style="font-size:30px">{{julyTotalSum}}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import api from "../../services/api";
import axios from "axios";
import HighchartsVue from "highcharts-vue";
import Highcharts, { color } from "highcharts";
import stockInit from "highcharts/modules/stock";
stockInit(Highcharts)
export default {
  data() {
    return {
      page: 1,
      byRouteLoaded: false,
      byReatilerLoaded:false,
      monthbyRouteLoaded:false,
      qtyTotalLoaded: false,
      divisionLoaded: false,
      Retailers: [],
      RetailersList: [],
      Category: [],
      DistributorCode: [],
      Routes: [],
      retailerDropdownValue :'All',
      categoryDropdownValue: 'All',
      distributorDropdownValue: 'All',
      routeDropdownValue: 'All',
      juneQuantityByRoute: [],
      mayQuantityByRoute: [],
      julyQuantityByRoute: [],
      juneQuantityByRetailer: [],
      mayQuantityByRetailer: [],
      julyQuantityByRetailer: [],
      currentMonthDataByRoute: [],
      mayTotalSum: 0,
      juneTotalSum: 0,
      julyTotalSum: 0,
      qtyMayTotalSum: 0,
      qtyJuneTotalSum: 0,
      qtyJulyTotalSum: 0,
      qtyTotalSum: 0,
      retailerFilterString: [],
      routeFilterArray: [],
      categoryFilterArray : [],
      distributorFilterArray: [],
      divisionData: [],
      categoryFilterString: '',
      distributorCodeFilterString:'',
      lastRetailerIndex:'',
      options: {},
      retailerOptions: {},
      currentMonthOptions: {},
      divisionpieOptions: {},
      totalQtyOptions:{},
      
    };
  },
  // mounted () {
  //     // axios.get('http://localhost:3000/users').then(response => (this.posts = response))
  //     this.getAllData()
  // },
  async created() {
    this.getAllData();
    // this.getRetailer(),
    // this.getCategory(),
    // this.getDistributorCode(),
    // this.getRoutes(),
    // this.getJuneQty(),
    // this.getJulyQty(),
    // this.getMayQty(),
    // this.highchartOptions()
  },
  methods: {
    getAllData() {
      api.getRetailers().then(data => {
        this.Retailers = data.map(inst => {
          return inst.Retailer_Name;
        });
        api.getCategory().then(category => {
          this.Category = category;
          api.getDistributorCode().then(code => {
            this.DistributorCode = code;
            api.getRoute().then(routes => {
              //console.log(routes);
              this.Routes = routes.map(inst => {
                return inst.Route;
              });
              //console.log(this.Routes);
              // api.getMonthValueByRoute().then(monthbyroute => {
              //   //this.junequantity = juneval;
              //   //console.log("june val",juneval.mayData)
              //   this.byRouteLoaded = true;
              //   this.juneQuantityByRoute = monthbyroute.juneData;
              //   this.mayQuantityByRoute = monthbyroute.mayData;
              //   this.julyQuantityByRoute = monthbyroute.julyData;
              //   // this.qtyjuneretailer = juneval.map(ins => {
              //   //   return ins.count;
              //   // });
              //   for (var i = 0; i < this.juneQuantityByRoute.length; i++) {
              //     this.juneQuantityByRoute[i] = parseInt(
              //       this.juneQuantityByRoute[i],
              //       10
              //     );
              //     this.mayQuantityByRoute[i] = parseInt(
              //       this.mayQuantityByRoute[i],
              //       10
              //     );
              //     this.julyQuantityByRoute[i] = parseInt(
              //       this.julyQuantityByRoute[i],
              //       10
              //     );
              //   }
              //   // console.log(
              //   //   this.juneQuantityByRoute,
              //   //   this.mayQuantityByRoute,
              //   //   this.julyQuantityByRoute
              //   // );
              //   this.options = {
              //     chart: {
              //       height: 300,
              //       type: "line"
              //     },
              //     title: {
              //       text: "Quantity(Monthly) by Route",
              //       x: -20 //center
              //     },
              //     xAxis: {
              //       categories: this.Routes,
              //       min: 0,
              //       max: 10,
              //       label: {
                        
              //         style: {
              //           width: 100
              //         }
              //       },
              //       scrollbar: {
              //         enabled: true
              //       }
              //     },
              //     yAxis: {
              //       title: {
              //         text: "Quantity"
              //       },
              //       plotLines: [
              //         {
              //           value: 0,
              //           width: 1,
              //           color: "#808080"
              //         }
              //       ]
              //     },
              //     tooltip: {
              //       valueSuffix: ""
              //     },
              //     //   scrollbar: {
              //     //     enabled: true
              //     //   },
              //     legend: {
              //       layout: "vertical",
              //       align: "right",
              //       verticalAlign: "middle",
              //       borderWidth: 0
              //     },
              //     plotOptions: {
              //       series: {
              //           cropThreshold: 1000,
              //         label: {
              //           connectorAllowed: true
              //         },
              //         pointWidth: 100
              //       }
              //     },
              //     credits: {
              //            enabled: false
              //           },
              //     series: [
              //       {
              //         name: "Qty_May_Route",
              //         data: this.mayQuantityByRoute,
              //         color: "yellow"
              //       },
              //       {
              //         name: "Qty_June_Route",
              //         data: this.juneQuantityByRoute,
              //         color : "black"
              //       },
              //       {
              //         name: "Qty_July_Route",
              //         data: this.julyQuantityByRoute,
              //         color: "#e2e2a7"
              //       }
              //     ],
              //     responsive: {
              //       rules: [
              //         {
              //           condition: {
              //             maxWidth: 10
              //           },
              //           chartOptions: {
              //             legend: {
              //               layout: "horizontal",
              //               align: "center",
              //               verticalAlign: "bottom"
              //             }
              //           }
              //         }
              //       ]
              //     }
              //   };
              //   api.getMonthValueByRetailer().then(monthbyretailer => {
              //     this.juneQuantityByRetailer = monthbyretailer.juneData;
              //     this.mayQuantityByRetailer = monthbyretailer.mayData;
              //     this.julyQuantityByRetailer = monthbyretailer.julyData;
              //     // this.qtyjuneretailer = juneval.map(ins => {
              //     //   return ins.count;
              //     // });
              //     this.byReatilerLoaded = true;
              //     for (var i = 0; i < this.juneQuantityByRetailer.length; i++) {
              //       this.juneQuantityByRetailer[i] = parseInt(
              //         this.juneQuantityByRetailer[i],
              //         10
              //       );
              //       this.mayQuantityByRetailer[i] = parseInt(
              //         this.mayQuantityByRetailer[i],
              //         10
              //       );
              //       this.julyQuantityByRetailer[i] = parseInt(
              //         this.julyQuantityByRetailer[i],
              //         10
              //       );
              //     }
              //     //   this.mayquantity = mayval;
              //     //   this.qtymayretailer = mayval.map(ins => {
              //     //     return ins.count;
              //     //   });
              //     //   for (var i = 0; i < this.qtymayretailer.length; i++)
              //     //     this.qtymayretailer[i] = parseInt(
              //     //       this.qtymayretailer[i],
              //     //       10
              //     //     );
              //     //   api.getJulyValue().then(julyval => {
              //     //     this.julyquantity = julyval;
              //     //     this.qtyjulyretailer = julyval.map(ins => {
              //     //       return ins.count;
              //     //     });
              //     //     for (var i = 0; i < this.qtyjulyretailer.length; i++)
              //     //       this.qtyjulyretailer[i] = parseInt(
              //     //         this.qtyjulyretailer[i],
              //     //         10
              //     //       );
              //     //     console.log(
              //     //       this.qtyjuneretailer,
              //     //       this.qtyjulyretailer,
              //     //       this.qtymayretailer
              //     //     );
              //     //console.log(this.Retailers.length);

              //     this.retailerOptions = {
              //       chart: {
              //         height:300,
              //         type: "line"
              //       },
              //       title: {
              //         text: "Quantity(Monthly) by Retailer",
              //         x: -20 //center
              //       },
              //       xAxis: {
              //         categories: this.Retailers,
              //         scrollbar: {
              //           enabled: true
              //         },
              //         min: 0,
              //         max: 10,
              //         label: {
              //           style: {
              //             width: 100
              //           }
              //         },
              //       },
              //       yAxis: {
              //         title: {
              //           text: "Quantity"
              //         },
              //         plotLines: [
              //           {
              //             value: 0,
              //             width: 1,
              //             color: "#808080"
              //           }
              //         ]
              //       },
              //       tooltip: {
              //         valueSuffix: ""
              //       },
              //       //   scrollbar: {
              //       //     enabled: true
              //       //   },
              //       legend: {
              //         layout: "vertical",
              //         align: "right",
              //         verticalAlign: "middle",
              //         borderWidth: 0
              //       },
              //       plotOptions: {
              //         series: {
              //           label: {
              //             connectorAllowed: false
              //           },
              //           pointWidth: 100,
              //           cropThreshold: 100
              //         }
              //       },
              //       credits: {
              //            enabled: false
              //           },
              //       series: [
              //         {
              //           name: "Qty_May_Retailer",
              //           data: this.mayQuantityByRetailer,
              //           color: "yellow"

              //         },
              //         {
              //           name: "Qty_June_Retailer",
              //           data: this.juneQuantityByRetailer,
              //           color: "black"

              //         },
              //         {
              //           name: "Qty_July_Retailer",
              //           data: this.julyQuantityByRetailer,
              //           color: "#e2e2a7"

              //         }
              //       ],
              //       responsive: {
              //         rules: [
              //           {
              //             condition: {
              //               maxWidth: 10
              //             },
              //             chartOptions: {
              //               legend: {
              //                 layout: "horizontal",
              //                 align: "center",
              //                 verticalAlign: "bottom"
              //               }
              //             }
              //           }
              //         ]
              //       }
              //     };
              //     api.getJulybyRoute().then(responseData => {
              //       this.currentMonthDataByRoute = responseData.julySum;
              //       // this.qtyjuneretailer = juneval.map(ins => {
              //       //   return ins.count;
              //       // });
              //       this.monthbyRouteLoaded = true;
              //       console.log(this.currentMonthDataByRoute, responseData);
              //       for (
              //         var i = 0;
              //         i < this.currentMonthDataByRoute.length;
              //         i++
              //       ) {
              //         this.currentMonthDataByRoute[i] = parseInt(
              //           this.currentMonthDataByRoute[i],
              //           10
              //         );
              //       }
              //       this.currentMonthOptions = {
              //         chart: {
              //           height:300,
              //           type: "bar"
              //         },
              //         title: {
              //           text: "Qty_july_retailer by Route and Month"
              //         },
              //         xAxis: {
              //           categories: this.Routes,
              //           title: {
              //             text: null
              //           },
              //           labels: {
              //               rotation: -30,
              //           },
              //           min: 0,
              //           max: 3,
              //           scrollbar: {
              //             enabled: true
              //           },
              //           tickLength: 0
              //         },
              //         yAxis: {
              //           min: 0,
              //           labels: {
                            
              //             overflow: "justify"

              //           }
              //         },
              //         tooltip: {
              //           valueSuffix: ""
              //         },
              //         plotOptions: {
              //           bar: {
              //             dataLabels: {
              //               enabled: true
              //             }
              //           },
              //           series: {
              //             pointWidth: 10,
              //             pointPadding: 1
              //           },
              //           scrollbar: {
              //             enabled: true
              //           }
              //         },
              //         //   legend: {
              //         //     layout: "vertical",
              //         //     align: "right",
              //         //     verticalAlign: "top",
              //         //     x: -40,
              //         //     y: 80,
              //         //     floating: true,
              //         //     borderWidth: 1,
              //         //     // backgroundColor:
              //         //     //   Highcharts.defaultOptions.legend.backgroundColor ||
              //         //     //   "#FFFFFF",
              //         //     shadow: true
              //         //   },
              //         //   plotOptions: {
              //         //     series: {
              //         //       label: {
              //         //         connectorAllowed: true
              //         //       },
              //         //       pointStart: 2010
              //         //     }
              //         //   },
              //         credits: {
              //            enabled: false
              //           },
              //         series: [
              //           {
              //             //   name: "Qty_May_Retailer",
              //             data: this.currentMonthDataByRoute,
              //             color: "black"
              //           }
              //         ],
              //         responsive: {
              //           rules: [
              //             {
              //               condition: {
              //                 maxWidth: 10
              //               },
              //               chartOptions: {
              //                 //   legend: {
              //                 //     layout: "horizontal",
              //                 //     align: "center",
              //                 //     verticalAlign: "bottom"
              //                 //   }
              //               }
              //             }
              //           ]
              //         }
              //       };
              //       api.getMonthTotal().then(sumData => {
              //           (this.mayTotalSum = sumData.maySum),
              //           (this.juneTotalSum = sumData.juneSum),
              //           (this.julyTotalSum = sumData.julySum);
              //         console.log(
              //           this.mayTotalSum,
              //           this.juneTotalSum,
              //           this.julyTotalSum
              //         );
              //       });
              //     });
              //   });
              // });
              this.fetchAllChartData('','all')
            });
          });
        });
      });
      // });
    },
    // getDatabyRetailer(retailer){
    //   if(retailer != ' '){
    //     this.byReatilerLoaded = false;
    //     let itemindex = this.retailerFilterString.indexOf(retailer);
    //     if(itemindex > -1){
    //       //if same retailer name found then remove it
    //       this.retailerFilterString.splice(itemindex,1)
    //     }
    //     else{
    //       this.retailerFilterString.push(retailer)
    //     }
    //     console.log(this.retailerFilterString.length)
    //     if(this.retailerFilterString.length == 0){
    //       api.getMonthValueByRetailer().then(data => {
    //         this.juneQuantityByRetailer = [];
    //         this.mayQuantityByRetailer = [];
    //         this.julyQuantityByRetailer = [];
    //         this.juneQuantityByRetailer = data.juneData;
    //         this.mayQuantityByRetailer = data.mayData;
    //         this.julyQuantityByRetailer = data.julyData;
    //         this.byReatilerLoaded = true;
    //         console.log(this.juneQuantityByRetailer,this.mayQuantityByRetailer);
    //         for (var i = 0; i < this.juneQuantityByRetailer.length; i++) {
    //           this.juneQuantityByRetailer[i] = parseInt(
    //             this.juneQuantityByRetailer[i],
    //             10
    //           );
    //           this.mayQuantityByRetailer[i] = parseInt(
    //             this.mayQuantityByRetailer[i],
    //             10
    //           );
    //           this.julyQuantityByRetailer[i] = parseInt(
    //             this.julyQuantityByRetailer[i],
    //             10
    //           );
    //         }
    //         this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer)
    //       })
    //     }
    //     else{
    //       api.getDataBasedonRetailer(this.retailerFilterString).then(databyretailer => {
    //         console.log("In response",databyretailer)
    //         this.juneQuantityByRetailer = [];
    //         this.mayQuantityByRetailer = [];
    //         this.julyQuantityByRetailer = [];
    //         this.juneQuantityByRetailer = databyretailer.juneData;
    //         this.mayQuantityByRetailer = databyretailer.mayData;
    //         this.julyQuantityByRetailer = databyretailer.julyData;
    //         this.byReatilerLoaded = true;
    //         //this.Retailer = this.retailerFilterString;
    //         for (var i = 0; i < this.juneQuantityByRetailer.length; i++) {
    //           this.juneQuantityByRetailer[i] = parseInt(
    //             this.juneQuantityByRetailer[i],
    //             10
    //           );
    //           this.mayQuantityByRetailer[i] = parseInt(
    //             this.mayQuantityByRetailer[i],
    //             10
    //           );
    //           this.julyQuantityByRetailer[i] = parseInt(
    //             this.julyQuantityByRetailer[i],
    //             10
    //           );
    //         }
    //         this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer)
    //       });
    //     }
    //   }
      
        
        
      
      
    //   // retailer = retailer.concat(' ')
    //   // this.retailerFilterString = this.retailerFilterString.concat(`'` + retailer + `',`)
    //   console.log(this.retailerFilterString,retailer,index)
      
    // },
//     getDatabyroute(route){
//       if(route != ' '){
// this.byRouteLoaded = false;
//       let itemindex = this.routeFilterArray.indexOf(route);
//       if(itemindex > -1){
//         this.routeFilterArray.splice(itemindex,1)
//       }
//       else{
//         this.routeFilterArray.push(route)
//       }
//       if(this.routeFilterArray.length == 0){
//         api.getMonthValueByRoute().then(responseData => {
//           this.juneQuantityByRoute = responseData.juneData;
//           this.mayQuantityByRoute = responseData.mayData;
//           this.julyQuantityByRoute = responseData.julyData;
//           this.byRouteLoaded = true;
//           for (var i = 0; i < this.juneQuantityByRoute.length; i++) {
//             this.juneQuantityByRoute[i] = parseInt(
//               this.juneQuantityByRoute[i],
//               10
//             );
//             this.mayQuantityByRoute[i] = parseInt(
//               this.mayQuantityByRoute[i],
//               10
//             );
//             this.julyQuantityByRoute[i] = parseInt(
//               this.julyQuantityByRoute[i],
//               10
//             );
//           };
//           this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
//         })
//       }
//       else{
//         api.getDataBasedonRoute(this.routeFilterArray).then(responseData => {
//           this.juneQuantityByRoute = responseData.juneData;
//           this.mayQuantityByRoute = responseData.mayData;
//           this.julyQuantityByRoute = responseData.julyData;
//           this.byRouteLoaded = true;
//           //this.Retailer = this.retailerFilterString;
//           for (var i = 0; i < this.juneQuantityByRoute.length; i++) {
//             this.juneQuantityByRoute[i] = parseInt(
//               this.juneQuantityByRoute[i],
//               10
//             );
//             this.mayQuantityByRoute[i] = parseInt(
//               this.mayQuantityByRoute[i],
//               10
//             );
//             this.julyQuantityByRoute[i] = parseInt(
//               this.julyQuantityByRoute[i],
//               10
//             );
//           }
//           this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
//         })
//       }
//       }
      
//     },
//     getDataByCategory(category){
//       let itemindex = this.categoryFilterArray.indexOf(category);
//       if(itemindex > -1){
//         this.categoryFilterArray.splice(itemindex,1)
//       }
//       else{
//         this.categoryFilterArray.push(category)
//       }
//       if(this.categoryFilterArray.length == 0){
//         this.getDatabyRetailer(' ');
//         this.getDatabyroute(' ');
//       }
//       else{
//         // if(this.retailerFilterString.length == 0 && this.routeFilterArray.length == 0)
//       }
//     },
    fetchAllChartData(data,type){
      if(type == 'all'){
        api.fetchAllData([
          this.retailerFilterString,this.distributorFilterArray,
          this.categoryFilterArray,this.routeFilterArray])
        .then(response => {
          this.juneQuantityByRetailer = [];
          this.mayQuantityByRetailer = [];
          this.julyQuantityByRetailer = [];
          this.juneQuantityByRoute = [];
          this.mayQuantityByRoute = [];
          this.julyQuantityByRoute = [];
          this.juneQuantityByRoute = response.route.juneDataRoute;
          this.mayQuantityByRoute = response.route.mayDataRoute;
          this.julyQuantityByRoute = response.route.julyDataRoute;
          this.mayQuantityByRetailer = response.retailer.mayDataRetailer;
          this.juneQuantityByRetailer = response.retailer.juneDataRetailer;
          this.julyQuantityByRetailer = response.retailer.julyDataRetailer;
          this.currentMonthDataByRoute = response.julyData.julyData;
          this.julyTotalSum = response.monthSum.julySum;
          this.juneTotalSum = response.monthSum.juneSum;
          this.mayTotalSum = response.monthSum.maySum;
          this.divisionData = response.div.division;
          this.qtyMayTotalSum = response.allMonthData.mayTotalSum;
          this.qtyJuneTotalSum = response.allMonthData.juneTotalSum;
          this.qtyJulyTotalSum = response.allMonthData.julyTotalSum;
          this.byRouteLoaded= true;
          this.byReatilerLoaded=true;
          this.monthbyRouteLoaded=true;
          this.divisionLoaded = true;
          this.qtyTotalLoaded = true;
          if(this.retailerFilterString.length == 0){
            this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }else{
            this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }
          if(this.routeFilterArray.length == 0){
            this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.Routes,this.currentMonthDataByRoute)
          }else{
            this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.routeFilterArray,this.currentMonthDataByRoute)
          }
          this.divsionpieOptFunc(this.divisionData);
          this.totalQtyFunc([this.qtyMayTotalSum,this.qtyJuneTotalSum,this.qtyJulyTotalSum])
        })
      }
      else if(type == 'c'){
        this.byRouteLoaded= false;
        this.byReatilerLoaded=false;
        this.monthbyRouteLoaded=false;
        this.mayTotalSum = 0
        this.juneTotalSum = 0
        this.julyTotalSum = 0
        let itemIndex = this.categoryFilterArray.indexOf(data);
        if(itemIndex > -1){
          this.categoryFilterArray.splice(itemIndex,1)
        }
        else{
          this.categoryFilterArray.push(data)
        }
        api.fetchAllData([
          this.retailerFilterString,this.distributorFilterArray,
          this.categoryFilterArray,this.routeFilterArray])
        .then(response => {
          this.juneQuantityByRetailer = [];
          this.mayQuantityByRetailer = [];
          this.julyQuantityByRetailer = [];
          this.juneQuantityByRoute = [];
          this.mayQuantityByRoute = [];
          this.julyQuantityByRoute = [];
          this.juneQuantityByRoute = response.route.juneDataRoute;
          this.mayQuantityByRoute = response.route.mayDataRoute;
          this.julyQuantityByRoute = response.route.julyDataRoute;
          this.mayQuantityByRetailer = response.retailer.mayDataRetailer;
          this.juneQuantityByRetailer = response.retailer.juneDataRetailer;
          this.julyQuantityByRetailer = response.retailer.julyDataRetailer;
          this.currentMonthDataByRoute = response.julyData.julyData;
          this.julyTotalSum = response.monthSum.julySum;
          this.juneTotalSum = response.monthSum.juneSum;
          this.mayTotalSum = response.monthSum.maySum;
          this.qtyMayTotalSum = response.allMonthData.mayTotalSum;
          this.qtyJuneTotalSum = response.allMonthData.juneTotalSum;
          this.qtyJulyTotalSum = response.allMonthData.julyTotalSum;
          this.divisionData = response.div.division;
          this.byRouteLoaded= true;
          this.byReatilerLoaded=true;
          this.monthbyRouteLoaded=true;
          this.divisionLoaded = true;
          this.qtyTotalLoaded = true;
          if(this.retailerFilterString.length == 0){
            this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }else{
            this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }
          if(this.routeFilterArray.length == 0){
            this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.Routes,this.currentMonthDataByRoute)
          }else{
            this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.routeFilterArray,this.currentMonthDataByRoute)
          }
          this.divsionpieOptFunc(this.divisionData);
          this.totalQtyFunc([this.qtyMayTotalSum,this.qtyJuneTotalSum,this.qtyJulyTotalSum])
          console.log(this.juneQuantityByRetailer);
        })
      }else if(type == 'dc'){
        this.byRouteLoaded= false;
        this.byReatilerLoaded=false;
        this.monthbyRouteLoaded=false;
        this.mayTotalSum = 0
        this.juneTotalSum = 0
        this.julyTotalSum = 0
        let itemIndex = this.distributorFilterArray.indexOf(data);
        if(itemIndex > -1){
          this.distributorFilterArray.splice(itemIndex,1)
        }
        else{
          this.distributorFilterArray.push(data)
        }
        api.fetchAllData([
          this.retailerFilterString,this.distributorFilterArray,
          this.categoryFilterArray,this.routeFilterArray])
        .then(response => {
          this.juneQuantityByRetailer = [];
          this.mayQuantityByRetailer = [];
          this.julyQuantityByRetailer = [];
          this.juneQuantityByRoute = [];
          this.mayQuantityByRoute = [];
          this.julyQuantityByRoute = [];
          this.juneQuantityByRoute = response.route.juneDataRoute;
          this.mayQuantityByRoute = response.route.mayDataRoute;
          this.julyQuantityByRoute = response.route.julyDataRoute;
          this.mayQuantityByRetailer = response.retailer.mayDataRetailer;
          this.juneQuantityByRetailer = response.retailer.juneDataRetailer;
          this.julyQuantityByRetailer = response.retailer.julyDataRetailer;
          this.currentMonthDataByRoute = response.julyData.julyData;
          this.qtyMayTotalSum = response.allMonthData.mayTotalSum;
          this.qtyJuneTotalSum = response.allMonthData.juneTotalSum;
          this.qtyJulyTotalSum = response.allMonthData.julyTotalSum;
          this.julyTotalSum = response.monthSum.julySum;
          this.juneTotalSum = response.monthSum.juneSum;
          this.mayTotalSum = response.monthSum.maySum;
          this.byRouteLoaded= true;
          this.byReatilerLoaded=true;
          this.monthbyRouteLoaded=true;
          this.divisionLoaded = true;
          this.qtyTotalLoaded = true;
          if(this.retailerFilterString.length == 0){
            this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }else{
            this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }
          if(this.routeFilterArray.length == 0){
            this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.Routes,this.currentMonthDataByRoute)
          }else{
            this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.routeFilterArray,this.currentMonthDataByRoute)
          }
          this.divsionpieOptFunc(this.divisionData);
          this.totalQtyFunc([this.qtyMayTotalSum,this.qtyJuneTotalSum,this.qtyJulyTotalSum])
          console.log('success')
        })
      }
      else if(type == 'rn'){
        this.byRouteLoaded= false;
        this.byReatilerLoaded=false;
        this.monthbyRouteLoaded=false;
        this.mayTotalSum = 0
        this.juneTotalSum = 0
        this.julyTotalSum = 0
        let itemIndex = this.retailerFilterString.indexOf(data);
        if(itemIndex > -1){
          this.retailerFilterString.splice(itemIndex,1)
        }
        else{
          this.retailerFilterString.push(data)
        }
        api.fetchAllData([
          this.retailerFilterString,this.distributorFilterArray,
          this.categoryFilterArray,this.routeFilterArray])
        .then(response => {
          this.juneQuantityByRetailer = [];
          this.mayQuantityByRetailer = [];
          this.julyQuantityByRetailer = [];
          this.juneQuantityByRoute = [];
          this.mayQuantityByRoute = [];
          this.julyQuantityByRoute = [];
          this.juneQuantityByRoute = response.route.juneDataRoute;
          this.mayQuantityByRoute = response.route.mayDataRoute;
          this.julyQuantityByRoute = response.route.julyDataRoute;
          this.mayQuantityByRetailer = response.retailer.mayDataRetailer;
          this.juneQuantityByRetailer = response.retailer.juneDataRetailer;
          this.julyQuantityByRetailer = response.retailer.julyDataRetailer;
          this.currentMonthDataByRoute = response.julyData.julyData;
          this.julyTotalSum = response.monthSum.julySum;
          this.juneTotalSum = response.monthSum.juneSum;
          this.mayTotalSum = response.monthSum.maySum;
          this.qtyMayTotalSum = response.allMonthData.mayTotalSum;
          this.qtyJuneTotalSum = response.allMonthData.juneTotalSum;
          this.qtyJulyTotalSum = response.allMonthData.julyTotalSum;
          this.byRouteLoaded= true;
          this.byReatilerLoaded=true;
          this.monthbyRouteLoaded=true;
          this.divisionLoaded = true;
          this.qtyTotalLoaded = true;
          if(this.retailerFilterString.length == 0){
            this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }else{
            this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }
          if(this.routeFilterArray.length == 0){
            this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.Routes,this.currentMonthDataByRoute)
          }else{
            this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.routeFilterArray,this.currentMonthDataByRoute)
          }
          this.divsionpieOptFunc(this.divisionData);
          this.totalQtyFunc([this.qtyMayTotalSum,this.qtyJuneTotalSum,this.qtyJulyTotalSum])
          console.log('success')
        })
      }else if(type == 'r'){
        this.byRouteLoaded= false;
        this.byReatilerLoaded=false;
        this.monthbyRouteLoaded=false;
        this.mayTotalSum = 0
        this.juneTotalSum = 0
        this.julyTotalSum = 0;
        data = data.replace(/'/g,'');
        console.log(data)
        let itemIndex = this.routeFilterArray.indexOf(data);
        if(itemIndex > -1){
          this.routeFilterArray.splice(itemIndex,1)
        }
        else{
          this.routeFilterArray.push(data)
        }
        api.fetchAllData([
          this.retailerFilterString,this.distributorFilterArray,
          this.categoryFilterArray,this.routeFilterArray])
        .then(response => {
          this.juneQuantityByRetailer = [];
          this.mayQuantityByRetailer = [];
          this.julyQuantityByRetailer = [];
          this.juneQuantityByRoute = [];
          this.mayQuantityByRoute = [];
          this.julyQuantityByRoute = [];
          this.juneQuantityByRoute = response.route.juneDataRoute;
          this.mayQuantityByRoute = response.route.mayDataRoute;
          this.julyQuantityByRoute = response.route.julyDataRoute;
          this.mayQuantityByRetailer = response.retailer.mayDataRetailer;
          this.juneQuantityByRetailer = response.retailer.juneDataRetailer;
          this.julyQuantityByRetailer = response.retailer.julyDataRetailer;
          this.currentMonthDataByRoute = response.julyData.julyData;
          this.julyTotalSum = response.monthSum.julySum;
          this.juneTotalSum = response.monthSum.juneSum;
          this.mayTotalSum = response.monthSum.maySum;
          this.qtyMayTotalSum = response.allMonthData.mayTotalSum;
          this.qtyJuneTotalSum = response.allMonthData.juneTotalSum;
          this.qtyJulyTotalSum = response.allMonthData.julyTotalSum;
          this.byRouteLoaded= true;
          this.byReatilerLoaded=true;
          this.monthbyRouteLoaded=true;
          this.divisionLoaded = true;
          this.qtyTotalLoaded = true;
          if(this.retailerFilterString.length == 0){
            this.highchartOptions(this.Retailers,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }else{
            this.highchartOptions(this.retailerFilterString,this.mayQuantityByRetailer,this.juneQuantityByRetailer,this.julyQuantityByRetailer);
          }
          if(this.routeFilterArray.length == 0){
            this.dataByRouteOptions(this.Routes,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.Routes,this.currentMonthDataByRoute)
          }else{
            this.dataByRouteOptions(this.routeFilterArray,this.mayQuantityByRoute,this.juneQuantityByRoute,this.julyQuantityByRoute)
            this.currentMonthOpt(this.routeFilterArray,this.currentMonthDataByRoute)
          }
          this.divsionpieOptFunc(this.divisionData);
          this.totalQtyFunc([this.qtyMayTotalSum,this.qtyJuneTotalSum,this.qtyJulyTotalSum])
          console.log('success')
        });
      }
      
      
    },
    highchartOptions(retailers,mayData,juneData,julyData) {
      //this.Retailers = this.Retailers.map(inst => {return inst.Retailer_Name})
      this.retailerOptions = {
          chart: {
            height:'40%',
            type: "line"
          },
          title: {
            text: "Quantity(Monthly) by Retailer",
            x: -20 //center
          },
          xAxis: {
            categories: retailers,
            scrollbar: {
              enabled: true
            },
            min: 0,
            max: retailers.length > 10 ? 10 : retailers.length - 1,
            label: {
              style: {
                width: 100
              }
            },
          },
          yAxis: {
            title: {
              text: "Quantity"
            },
            plotLines: [
              {
                value: 0,
                width: 1,
                color: "#808080"
              }
            ]
          },
          tooltip: {
            valueSuffix: ""
          },
          //   scrollbar: {
          //     enabled: true
          //   },
          legend: {
            layout: "vertical",
            align: "right",
            verticalAlign: "middle",
            borderWidth: 0
          },
          plotOptions: {
            series: {
              label: {
                connectorAllowed: false
              },
              pointWidth: 100,
              cropThreshold: 100
            }
          },
          credits: {
              enabled: false
              },
          series: [
            {
              name: "Qty_May_Retailer",
              data: mayData,
              color: "yellow"

            },
            {
              name: "Qty_June_Retailer",
              data: juneData,
              color: "black"

            },
            {
              name: "Qty_July_Retailer",
              data: julyData,
              color: "#e2e2a7"

            }
          ],
          responsive: {
            rules: [
              {
                condition: {
                  maxWidth: 10
                },
                chartOptions: {
                  legend: {
                    layout: "horizontal",
                    align: "center",
                    verticalAlign: "bottom"
                  }
                }
              }
            ]
          }
        };
    },
    dataByRouteOptions(routes,mayData,juneData,julyData){
      this.options = {
                  chart: {
                    height: '40%',
                    type: "line"
                  },
                  title: {
                    text: "Quantity(Monthly) by Route",
                    x: -20 //center
                  },
                  xAxis: {
                    categories: routes,
                    min: 0,
                    max: routes.length > 10 ? 10 : routes.length - 1,
                    label: {
                        
                      style: {
                        width: 100
                      }
                    },
                    scrollbar: {
                      enabled: true
                    }
                  },
                  yAxis: {
                    title: {
                      text: "Quantity"
                    },
                    plotLines: [
                      {
                        value: 0,
                        width: 1,
                        color: "#808080"
                      }
                    ]
                  },
                  tooltip: {
                    valueSuffix: ""
                  },
                  //   scrollbar: {
                  //     enabled: true
                  //   },
                  legend: {
                    layout: "vertical",
                    align: "right",
                    verticalAlign: "middle",
                    borderWidth: 0
                  },
                  plotOptions: {
                    series: {
                        cropThreshold: 1000,
                      label: {
                        connectorAllowed: true
                      },
                      pointWidth: 100
                    }
                  },
                  credits: {
                         enabled: false
                        },
                  series: [
                    {
                      name: "Qty_May_Route",
                      data: this.mayQuantityByRoute,
                      color: "yellow"
                    },
                    {
                      name: "Qty_June_Route",
                      data: this.juneQuantityByRoute,
                      color : "black"
                    },
                    {
                      name: "Qty_July_Route",
                      data: this.julyQuantityByRoute,
                      color: "#e2e2a7"
                    }
                  ],
                  responsive: {
                    rules: [
                      {
                        condition: {
                          maxWidth: 10
                        },
                        chartOptions: {
                          legend: {
                            layout: "horizontal",
                            align: "center",
                            verticalAlign: "bottom"
                          }
                        }
                      }
                    ]
                  }
                };
    },
    currentMonthOpt(routes,currentMonthData){
      this.currentMonthOptions = {
                      chart: {
                        height:'40%',
                        type: "bar"
                      },
                      title: {
                        text: "Qty_july_retailer by Route and Month"
                      },
                      xAxis: {
                        categories: routes,
                        title: {
                          text: null
                        },
                        labels: {
                            rotation: -30,
                        },
                        min: 0,
                        max: 3,
                        scrollbar: {
                          enabled: true
                        },
                        tickLength: 0
                      },
                      yAxis: {
                        min: 0,
                        labels: {
                            
                          overflow: "justify"

                        }
                      },
                      tooltip: {
                        valueSuffix: ""
                      },
                      plotOptions: {
                        bar: {
                          dataLabels: {
                            enabled: true
                          }
                        },
                        series: {
                          pointWidth: 10,
                          pointPadding: 1
                        },
                        scrollbar: {
                          enabled: true
                        }
                      },
                      //   legend: {
                      //     layout: "vertical",
                      //     align: "right",
                      //     verticalAlign: "top",
                      //     x: -40,
                      //     y: 80,
                      //     floating: true,
                      //     borderWidth: 1,
                      //     // backgroundColor:
                      //     //   Highcharts.defaultOptions.legend.backgroundColor ||
                      //     //   "#FFFFFF",
                      //     shadow: true
                      //   },
                      //   plotOptions: {
                      //     series: {
                      //       label: {
                      //         connectorAllowed: true
                      //       },
                      //       pointStart: 2010
                      //     }
                      //   },
                      credits: {
                         enabled: false
                        },
                      series: [
                        {
                          //   name: "Qty_May_Retailer",
                          data: currentMonthData,
                          color: "black"
                        }
                      ],
                      responsive: {
                        rules: [
                          {
                            condition: {
                              maxWidth: 10
                            },
                            chartOptions: {
                              //   legend: {
                              //     layout: "horizontal",
                              //     align: "center",
                              //     verticalAlign: "bottom"
                              //   }
                            }
                          }
                        ]
                      }
                    };
    },
    divsionpieOptFunc(divData){
      var chartData;
      if(divData.length == 2){
        chartData = [{
          name: divData[0],
          y: 50.00
        },{
          name: divData[1],
          y: 50.00
        }
        ]
      }
      else{
        chartData = [{
          name: divData[0],
          y: 50.00
        }]
      }
      this.divisionpieOptions = {
        chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height:'130px',
        //width: '400px'
        },
        title: {
            text: '% of Division'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    distance: 10,
                    style:{
                      fontSize: "8px"
                    },
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
            }
        },
        credits: {
          enabled: false
        },
        series: [{
            name: 'Division',
            colorByPoint: true,
            data: chartData
        }]
      }
    },
    totalQtyFunc(summedUpArray){
      this.totalQtyOptions = {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie',
          height: '130px',
          //width: '400px'
        },
        title: {
            text: '% of Division'
        },
        tooltip: {
            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
            point: {
                valueSuffix: '%'
            }
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                    enabled: true,
                    distance:10,
                    style:{
                      fontSize: "8px"
                    },
                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                }
            }
        },
        credits: {
          enabled: false
        },
        series: [{
            name: 'Division',
            colorByPoint: true,
            data: [{
              name : 'Qty_may',
              y: summedUpArray[0]
            },
            {
              name : 'Qty_june',
              y: summedUpArray[1]
            },
            {
              name : 'Qty_july',
              y: summedUpArray[2]
            }]
        }]
      }
    }
  }
};
</script>
<style>
.headerrow {
  margin: 5px !important;
  background-color: yellow;
}
.headerdiv {
  background-color: black;
  color: white;
}
.customdown {
  list-style-type: none;
}
.dropdownbutton {
  width: 100%;
  margin-top: 10px;
}
.dropdown-menu.show {
  display: block;
  width: 100%;
  overflow: auto;
  height: 300px;
  font-size: 12px;
}
.highcharts-yaxis {
  fill: yellow;
}
</style>

