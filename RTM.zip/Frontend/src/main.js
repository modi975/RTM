import Vue from 'vue'
import 'bootstrap'
import App from './App.vue'
import Home from './components/Home/Home.vue';
import babelPolyfill from 'babel-polyfill';
import vuescroll from 'vuescroll';
import 'vuescroll/dist/vuescroll.css';
import InfiniteLoading from 'vue-infinite-loading';
// import HighCharts from 'highcharts';
import HighchartsVue from 'highcharts-vue';
import 'vue-loaders/dist/vue-loaders.css';
import VueLoaders from 'vue-loaders';
Vue.use(VueLoaders);
Vue.use(InfiniteLoading, { /* options */ });
Vue.use(vuescroll)
// Vue.use(HighCharts);
Vue.use(HighchartsVue);
Vue.component('app-home',Home);
new Vue({
  el: '#app',
  render: h => h(App)
})
