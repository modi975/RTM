
<template>
  <div id="app">
    <app-home></app-home>
  </div>
</template>

<script>
// import Home from '../src/components/Home/Home';
export default {
  name: 'app',
  data () {
    return{

    }
  }
}
</script>

<style>
@import'~bootstrap/dist/css/bootstrap.css';
</style>
